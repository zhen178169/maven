# easy-springmvc-maven
## An simple demo about how to use maven combine spring mvc,for blog sample
